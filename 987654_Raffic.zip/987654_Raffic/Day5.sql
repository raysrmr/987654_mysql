select tid from training where tname='jag';

select id,emp_name,age from employee where tid=(select tid from training where tname='jag');

select id,emp_name,age from employee where tid in (select tid from training where tname='jag');

insert into train select * from training;

select id,emp_name,age from employee where age=(select round(avg(age),0) from employee);



