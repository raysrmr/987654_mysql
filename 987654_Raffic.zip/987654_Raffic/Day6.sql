select * from employee;

select id,emp_name,joindate,salary from employee;

create view emp_view as select id,emp_name,joindate,salary from employee;

select * from emp_view;

alter view emp_view as select id,emp_name from employee where salary = 25000;

create index emp_index on employee (emp_name);