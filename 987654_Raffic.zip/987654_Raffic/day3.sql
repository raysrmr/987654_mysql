create table employee (id int primary key,emp_name varchar(30), joindate date, age int, salary double);
insert into employee values(101,'Raffic','2021-12-01',21,23000.00);
insert into employee values(102,'Afee','2021-11-30',19,43000.00);
insert into employee values
(103,'Rajesh','2021-12-12',23,25000.00),
(104,'Ram','2021-11-02',23,25000.00),
(105,'Karthi','2021-12-22',24,35000.00),
(106,'Guhan','2021-10-02',21,27000.00),
(107,'Murugavel','2021-11-02',23,20000.00);
select * from employee;
select count(id) from employee;
select count(id) from employee where age>23;
select avg(salary) from employee;
select avg(salary) as 'Average Salary' from employee where salary>=25000;
select count(salary) from employee where salary>=25000;
select min(salary) from employee;
select current_date();
insert into employee values(108,'Ayaan',current_date(),19,41000.00);
insert into employee values(109,'Afraz',current_date(),20,42000.00);
insert into employee values(110,'Rasul',current_date(),null,51000.00);
select id,upper(emp_name),age from employee;
select id,substring(emp_name,2,4) from employee;
select avg(salary) from employee;
select abs(avg(salary)) from employee;
select round(avg(salary),2) from employee;
select floor(avg(salary)) from employee;
select floor(3.14);
select ceil(3.14);
select id, emp_name, joindate as 'Acutal Join Date',adddate(joindate,interval 20 day) as 'Added Join Date' from employee;
select joindate,extract(day from joindate) from employee;
select id, emp_name, age,
case 
when age>20 and age<30 then 'In Twenty'
when age>30 and age<40 then 'above Thirty'
else 'Below Twebty'
end as 'Result'
from employee;