select age from employee order by age desc;
select age,count(id) from employee group by age order by age desc;
select age,count(id) from employee where age>20 group by age order by age desc;
select age,count(id),avg(salary) from employee where age>20 group by age order by age desc;
select id,emp_name,age from employee where age=21 order by age desc;
select age,count(id) from employee where age>20 group by age having count(id)>=2 order by age desc;
select age,count(id) from employee group by age having count(id)>=2 order by age desc;

insert into training values(1,'tirupathi',3,'banking'),(2,'jag',4,'health care'),(3,'Gopal',2,'defence');

select e.id,e.emp_name,e.tid,t.tname,t.duration,t.domain from employee e inner join training t on e.tid=t.tid;

select e.id,e.emp_name,e.tid,t.tname,t.duration,t.domain from employee e left join training t on e.tid=t.tid;

select e.id,e.emp_name,e.tid,t.tname,t.duration,t.domain from employee e right join training t on e.tid=t.tid;



