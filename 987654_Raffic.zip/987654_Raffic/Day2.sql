create database ipm002;
use ipm002;
create table student_info(id int primary key, sname varchar(30), age int, city varchar(20), phone varchar(12));

alter table student_info add constraint ch_age check(age>=18);
create table student_info(id int, sname varchar(30), age int, city varchar(20), phone varchar(12), primary key(id));
describe student_details;
insert into student_details (regNo,first_name,second_name,age,city,phone,gender) 
values(1001,'Raffic','Rasul',21,'Dindigul','9944471841','male');
select * from student_details;

insert into student_details values(1002,'Ram','Balu',21,'Dindigul','9944471842','male');

insert into student_details (regNo,first_name,second_name,age,phone,gender) values(1002,'Ram','Balu',21,'9944471842','male');
insert into student_details values
(1003,'Rajesh','Joseph',21,'Dindigul','9944471843','male'),
(1004,'Karthi','Selvaraj',21,'Dindigul','987897834','Male'),
(1005,'Guhan','Thilaga',21,'Dindigul','45654677','male');

update student_details set city='Chennai' where regNo=1002; 

delete from student_details where regNo=1002;

select * from student_details;

start transaction;
delete from student_details where regNo=1003;
select * from student_details;
rollback;
select * from student_details;
commit;

start transaction;
delete from student_details where regNo=1003;
commit;
select * from student_details;
rollback;
select * from student_details;
commit;


select regNo,first_name,age,city from student_details;

select * from student_details where regNo=1001;
select regNo,age,city from student_details where regNo=1001;


drop table student_detail;

insert into student_info values
(1001,'RAfee',21,'Dindigul','9944471841'),
(1002,'Raffic',21,'Chennai','987897834'),
(1003,'Rajesh',21,'Madurai','9944471843'),
(1004,'Karthi',21,'Theni','987897834'),
(1005,'Guhan',21,'Chennai','45654677');

alter table student_info add constraint mobile_uni unique(phone);

insert into student_info values(1006,'Ayyan',21,'Salem',909841345);

insert into student_info values(1007,'Banu',21,'Salem',909841345);

insert into student_info values(1008,'Ban',19,'Salem',909841349);


update student_info set id=2001 where id=1001;

insert into stu (fname)values('A');
insert into stu (fname)values('B');
insert into stu (fname)values('C');

update stu set regno=5 where regno=1;

create table deaprtment (id int primary key, dept_name varchar(30),dept_head varchar(30),sid int,
 constraint fk_regno foreign key(sid) references student_info(id));
 
 
 
 insert into deaprtment values(101,'ECE','Raju',1002);
 insert into deaprtment values(102,'ECE','Raju',1006);
 
 insert into deaprtment (id,dept_name,sid)values(103,'ECE',1003);
 
 update student_info set id=2002 where id=1002;
 
 select age+2 from student_info;
 
 select age+2 as Added_Age from student_info;
 
 select id,sname,age from student_info where age>=20;
 
 select id,sname,age from student_info where age>19 and age<23;
 
 select id,sname,age from student_info where  age between 19 and 23;
 
 
 select id,sname,age from student_info where city in('dindigul','kolkatta','madurai');
 select id,sname,age from student_info where city not in('dindigul','chenai','madurai');
 
 select id,sname,age,city from student_info where city like 'C%';
 select id,sname,age,city from student_info where city like '%i';
 select id,sname,age,city from student_info where city like '%a%';
 
 