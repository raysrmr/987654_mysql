create database ipm002;
use ipm002;
create table student_info(id int primary key, sname varchar(30), age int, city varchar(20), phone varchar(12));
describe student_details;
insert into student_details (regNo,first_name,second_name,age,city,phone,gender) 
values(1001,'Raffic','Rasul',21,'Dindigul','9944471841','male');
select * from student_details;

insert into student_details values(1002,'Ram','Balu',21,'Dindigul','9944471842','male');

insert into student_details (regNo,first_name,second_name,age,phone,gender) values(1002,'Ram','Balu',21,'9944471842','male');
insert into student_details values
(1003,'Rajesh','Joseph',21,'Dindigul','9944471843','male'),
(1004,'Karthi','Selvaraj',21,'Dindigul','987897834','Male'),
(1005,'Guhan','Thilaga',21,'Dindigul','45654677','male');

update student_details set city='Chennai' where regNo=1002; 

delete from student_details where regNo=1002;

select * from student_details;

start transaction;
delete from student_details where regNo=1003;
select * from student_details;
rollback;
select * from student_details;
commit;

start transaction;
delete from student_details where regNo=1003;
commit;
select * from student_details;
rollback;
select * from student_details;
commit;


select regNo,first_name,age,city from student_details;

select * from student_details where regNo=1001;
select regNo,age,city from student_details where regNo=1001;


drop table student_detail
